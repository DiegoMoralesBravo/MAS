import torch
import numpy as np
import torch
import matplotlib.pyplot as plt
import cv2
import sys
import tkinter as tk
from segment_anything import sam_model_registry, SamAutomaticMaskGenerator, SamPredictor
from tkinter import filedialog
from tkinter import messagebox


def click_event(event, x, y, flags, params):
    global line
    global flag
    global img
    global lenLineX

    if event == cv2.EVENT_LBUTTONDOWN:
        font = cv2.FONT_HERSHEY_SIMPLEX

        if flag:
            flag = False
            line[0] = (x, y)
            line[1] = 0
            img = cv2.imread(filePath, 1)
            newImg = cv2.circle(img, line[0], 0, (0, 0, 255), 15)
            cv2.putText(img, 'P1 ' + str(line[0]), (x - 40, y - 40), font, 0.5, (0, 0, 255), 2)
            cv2.imshow('image', newImg)
            
        else:
            flag = True
            line[1] = (x, y)
            newImg = cv2.circle(img, line[1], 0, (0, 0, 255), 5)
            cv2.imshow('image', newImg)

        if line[0] != 0 and line[1] != 0:
            lenLineX = abs(line[0][0] - line[1][0])
            
            img = cv2.imread(filePath, 1)  # Reassign the original image to clear the previously drawn line
            cv2.putText(img, 'P1 ' + str(line[0]), (line[0][0] - 40, line[0][1] - 40), font, 0.5, (0, 0, 255), 2)
            cv2.putText(img, 'P2 ' + str(line[1]), (line[1][0] - 20, line[1][1] - 20), font, 0.5, (0, 0, 255), 2)
            newImg = cv2.line(img, line[0], line[1], (0, 0, 255), 3)
            cv2.imshow('image', newImg)
            cv2.waitKey(1)
            
            # Mostrar el cuadro de diálogo de confirmación
            result = messagebox.askyesno("Confirmación", "¿La longitud: " + str(lenLineX) + 'px es correcta?')

            # Comprobar el resultado de la confirmación
            if result:
                cv2.destroyAllWindows()
                return lenLineX

def show_anns(anns, image, xList, yList, stepNumber):
    heightImage = image.shape[0]
    widthImage = image.shape[1]
    minHeight = heightImage
    minArea = anns[0]['area']
    maxArea = anns[0]['area']

    if len(anns) == 0:
        return

    sorted_anns = sorted(anns, key=(lambda x: x['area']), reverse = True)

    for ann in sorted_anns:
        bbox = ann['bbox']
        area = ann['area']

        if bbox[0] < 10 and bbox[1] > (heightImage * 0.70) and bbox[2] > (widthImage * 0.7) and bbox[3] < (heightImage * 0.3):
            minHeight = bbox[1]

    sorted_anns = removeContainers(sorted_anns, minHeight, image)

    for ann in sorted_anns:
        bbox = ann['bbox']
        area = ann['area']

        if area < minArea:
            minArea = area
        if area > maxArea:
            maxArea = area

    step = (maxArea - minArea) / stepNumber

    for i in range(stepNumber):
        xList.append(str(round(minArea + (step * (i + 1)))))


    for ann in sorted_anns:
        bbox = ann['bbox']
        area = ann['area']
        cv2.rectangle(image, (bbox[0], bbox[1]),(bbox[0] + bbox[2], bbox[1] + bbox[3]), color=(0,0,255), thickness=1)
        fillDataChart(area, xList, yList)
    return image

def fillDataChart(area, xList, yList):
    for i, areaXlist in enumerate(xList):
        if area <= int(areaXlist):
            yList[i] += 1
            break

def removeContainers(anns, minHeight, image):
    minHeightAnns = [ann for ann in anns if ann['bbox'][1] < minHeight]
    withoutCointanerAnss = []

    for i in range(len(minHeightAnns)):
        counter = 0
        flag = True
        pxTainer = minHeightAnns[i]['bbox'][0]
        pyTainer = minHeightAnns[i]['bbox'][1]
        withTainer = minHeightAnns[i]['bbox'][2]
        heightTainer = minHeightAnns[i]['bbox'][3]

        for j in range(i + 1, len(minHeightAnns)):
            pxTained = minHeightAnns[j]['bbox'][0]
            pyTained = minHeightAnns[j]['bbox'][1]
            withTained = minHeightAnns[j]['bbox'][2]
            heightTained = minHeightAnns[j]['bbox'][3]

            if pxTained >= pxTainer - 5 and (pxTained + withTained) <= (pxTainer + withTainer + 5) and pyTained >= pyTainer - 5 and (pyTained + heightTained) <= (pyTainer + heightTainer + 5):
                counter += 1
                if counter == 2:
                    flag = False
                    break

        if flag:
            withoutCointanerAnss.append(minHeightAnns[i])

    return withoutCointanerAnss


if __name__=="__main__":
    
    root = tk.Tk()
    root.withdraw()
    
    # Get the monitor resolution
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    
    print('Micrograph Analysis System \n')
    flag = input('La imagen cuenta con barra indicadora de medida (Y/N)')
    if flag == 'Y' or flag == 'y':
        nanometros = input('Ingresa escala en nanometros: ')
        flagMeasure = True
    else:
        flagMeasure = False
    
    # Ask the user the image files to label
    filePath = filedialog.askopenfilename() # TODO - askopenfilenames... retrieve all the file names
    
    line = [0, 0]
    flag = True
    lenLineX = 0
    factor = 1
    
    # Read the image
    img = cv2.imread(filePath, 1)
    imgSize = img.shape
    imgHeight = imgSize[0]
    imgWidth = imgSize[1]
    
    if flagMeasure:
        cv2.namedWindow('image', cv2.WINDOW_NORMAL)
        cv2.imshow('image', img)

        # Resize the Window, close to the screen resolution
        cv2.resizeWindow('image', screen_width-100, screen_height-150)

        # setting mouse handler for the image and calling the click_event() function
        lineLen = cv2.setMouseCallback('image', click_event)
        # wait for a key to be pressed to exit
        repeatSelection = cv2.waitKey(0)

        # close the window
        cv2.destroyAllWindows()
        factor = int(nanometros) / lenLineX
        
    print(factor)

    sam_checkpoint = "sam_vit_h_4b8939.pth"
    model_type = "vit_h"
    

    cudaFlag = torch.cuda.is_available()
    print("CUDA is available:", cudaFlag)

    if cudaFlag:
        flag = input('Use GPU available? Y/N')
        if flag == 'Y' or flag == 'y':
            device = "cuda"
        else:
            device = "cpu"
    else:
        device = "cpu"

    sam = sam_model_registry[model_type](checkpoint=sam_checkpoint)
    sam.to(device=device)

    mask_generator = SamAutomaticMaskGenerator(sam)

    mask_generator = SamAutomaticMaskGenerator(
        model=sam,
        points_per_side= 44, 
        pred_iou_thresh = 0.85,
        stability_score_thresh = 0.97,
        crop_n_layers = 1,
        crop_n_points_downscale_factor = 2,
        min_mask_region_area= 1000,
    )

    stepNumber = 20
    xList = []
    yList = [0] * stepNumber

    image = cv2.imread(filePath)

    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    masks = mask_generator.generate(image)
    image = show_anns(masks, image, xList, yList, stepNumber)

    fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(20, 10))
    ax1.imshow(image)
    ax2.bar(x=[round(x*factor, 2) for x in xList], height=yList)
    plt.savefig('figure.png')
